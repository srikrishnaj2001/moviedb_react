import Navbar from './components/Navbar'
import Popular from './components/Popular'
import NowPlaying from './components/NowPlaying'
import Upcoming from './components/Upcoming'
import TopRated from './components/TopRated'
import TvPopular from './components/TvPopular'
import TVAiringToday from './components/TvAiringToday'
import TvOnTv from './components/TvOnTv'
import TvTopRated from './components/TvTopRated'
import PeoplePopular from './components/PeoplePopular'
import './App.css'
import {
  BrowserRouter as Router,
  Routes,
  Switch,
  Route,
  Link,
} from 'react-router-dom'
import { Container, Image } from '@chakra-ui/react'

function App() {
  return (
    <>
      <Navbar />
      <br />
      <br />
      <Container maxW='container.xl'>
        <Image
          src='banner.png'
          fallbackSrc='https://via.placeholder.com/150'
          height='450px'
          width='100%'
          borderRadius='10px'
          fit='cover'
        />
      </Container>

      <Router>
        <Routes>
          <Route path='/' element={<Popular />} />
          <Route path='/NowPlaying' element={<NowPlaying />} />
          <Route path='/PeoplePopular' element={<PeoplePopular />} />
          <Route path='/TopRated' element={<TopRated />} />
          <Route path='/TVAiringToday' element={<TVAiringToday />} />
          <Route path='/TvOnTv' element={<TvOnTv />} />
          <Route path='/TvPopular' element={<TvPopular />} />
          <Route path='/TvTopRated' element={<TvTopRated />} />
          <Route path='/Upcoming' element={<Upcoming />} />
        </Routes>
      </Router>
    </>
  )
}

export default App
